# Evaluating and Preserving Laboratory Relationships in Synthetic Clinical Tables: code and results

This release accompanies the manuscript in `paper/ieee/main.pdf`. It contains:
- the MedHyperDiff package and the scripts and tests used for every study in the paper;
- the dated protocols and runbooks;
- archived source snapshots for each study, with hashes;
- the result tables from which the manuscript's tables and figures are generated.

## Contents

| Path | What it is |
|---|---|
| `src/medhyperdiff/` | Package: data builders, preprocessing, diffusion model, relation reparameterization (`relations.py`), constraints, evaluation |
| `scripts/` | Study runners (`iteration11.py` to `iteration15.py`), report scripts, post hoc controls (`controls_iteration14.py`), final comparison (`report_final.py`), figure scripts, `fetch_data.py` |
| `tests/` | 64 tests |
| `configs/` | Frozen splits and development choices |
| `docs/` | Protocols with dated amendments (`ITERATION_*_PROTOCOL.md`) and runbooks |
| `reproducibility/` | Source snapshots by SHA-256, archived runner scripts and the reproducibility log (`reproducibility/README.md`) |
| `reports/` | Result tables per study (`iteration11` to `iteration15`, `final`) |
| `paper/ieee/` | LaTeX source, figures, generated table rows and the compiled PDF |

## Setup

Python 3.13, CPU only. The studies were run on an Apple M4 laptop.

```bash
uv venv && uv pip install -r requirements-lock.txt
export PYTHONPATH=src:scripts OMP_NUM_THREADS=1
```

The two diffusion baselines are imported from unmodified upstream source at pinned commits:

```bash
git clone https://github.com/MinkaiXu/TabDiff external/TabDiff
git -C external/TabDiff checkout 5ecdb3356261aea72716cc9a779f31d7ad083bf4
git clone https://github.com/yandex-research/tab-ddpm external/tab-ddpm
git -C external/tab-ddpm checkout b476257dd460b778ba09eb97f7a51d6490fa17f8
```

## Data

All data are public: NHANES public-use files (National Center for Health Statistics, U.S. public domain) and the UCI Machine Learning Repository (CC BY 4.0).

```bash
python scripts/fetch_data.py
```

This downloads the source files and checks the SHA-256 of every NHANES file. It writes `data/raw` and `data/processed`.

## Tests

```bash
python -m pytest -q tests
```

All 64 tests pass when both pinned baselines are present; without them, two baseline tests are skipped.

## Reproducing the studies

Splits are frozen in `configs/*_splits.json`, and `prepare` stages refuse to overwrite them. Each runbook in `docs/` lists the exact commands. The steps below are in the order the paper reports them.

**Controlled study of pitfalls** (Sections V and VI):
```bash
python scripts/iteration12.py run --workers 5
python scripts/report_iteration12.py
```

**Training decomposition** (Section VI, Table V):
```bash
python scripts/iteration15.py run --workers 8
python scripts/iteration15.py report
```

**First relation test, 2017–18 blood counts** (Section VIII):
```bash
python scripts/iteration13.py develop
python scripts/iteration13.py confirm
python scripts/report_iteration13.py
```

**Robustness study** (Section IX):
```bash
python scripts/iteration14.py queue --workers 8
python scripts/iteration14.py choose
python scripts/iteration14.py confirm --arms mhd
python scripts/report_iteration14.py
python scripts/reanalysis_iteration14.py relations
python scripts/reanalysis_iteration14.py canonical
python scripts/reanalysis_iteration14.py report
```

**Post hoc controls and final comparison:**
```bash
python scripts/controls_iteration14.py run --workers 8
python scripts/report_final.py paper/ieee/tables
python scripts/figure_final.py paper/ieee/figures/robustness_final.png
python scripts/figure_first_test.py paper/ieee/figures/relation_fidelity_final.png
```

**Remaining print figures:**
```bash
python scripts/figures_print.py reproducibility/figure_inputs paper/ieee/figures
```

**Compute.** TabDiff dominates the cost. The robustness study took about a day with eight concurrent single-threaded jobs. The run records (`runs/`, about 1 GB, with every synthetic table and manifest) are not included in this release; they are available from the authors.

## Source snapshots

Each run manifest records the SHA-256 of the package source it used, and `reproducibility/source_snapshots/<hash>/` holds that exact source.

| Study | Source snapshot |
|---|---|
| Controlled study | `3aafec1c…` |
| First relation test | `36533bf5…` |
| Robustness study | `890ebbee…` |
| Training decomposition | `1003bc8c…` |
| Post hoc controls and final comparison | `1626362e…` |

The package-directory hash is the SHA-256 over each sorted top-level `.py` filename followed by its bytes.
