"""Auditable constraints with physical-unit residuals and observed-value coverage.

Confidence here is a fixed sensitivity weight, not calibrated uncertainty.
Real-data algebraic rules are soft until assay/rounding semantics are reviewed.
"""
from dataclasses import dataclass, asdict, replace

import numpy as np
import pandas as pd
import torch


PROTEIN_SOURCE = "https://medlineplus.gov/lab-tests/total-protein-and-albumin-globulin-a-g-ratio/"
BILIRUBIN_SOURCE = "https://medlineplus.gov/ency/article/003479.htm"


@dataclass(frozen=True)
class Rule:
    name: str
    kind: str
    columns: tuple[str, ...]
    confidence: float = 1.0
    tolerance: float = 0.0
    scale: float = 1.0
    bound: float = 0.0
    status: str = "schema"
    source: str = ""
    units: str = "source measurement units; assay compatibility requires review"
    review_status: str = "not clinically reviewed"
    # Coefficients of a "linear" rule: derived = bound + sum(weights * operands).
    weights: tuple[float, ...] = ()


class ConstraintSet:
    def __init__(self, rules):
        self.rules = list(rules)
        for rule in self.rules:
            if rule.scale <= 0 or rule.tolerance < 0 or not 0 <= rule.confidence <= 1:
                raise ValueError("Constraint scale, tolerance, or confidence is invalid")

    def to_dict(self):
        return [asdict(r) for r in self.rules]

    def hyperedges(self, names):
        return [[names.index(c) for c in r.columns] for r in self.rules if len(r.columns) >= 2]

    @staticmethod
    def residual(rule, values):
        v = [values[c] for c in rule.columns]
        if rule.kind == "lower":
            return rule.bound - v[0]
        if rule.kind == "upper":
            return v[0] - rule.bound
        if rule.kind == "le":
            return v[0] - v[1]
        if rule.kind == "protein":
            # Algebraically equivalent to r = a/(t-a) for t>a, without singularity.
            total, albumin, ratio = v
            return abs(ratio * (total - albumin) - albumin)
        if rule.kind == "difference":
            # Definitional c = a - b (for example NHANES globulin = total protein - albumin).
            derived, a, b = v
            return abs(derived - (a - b))
        if rule.kind == "ratio":
            # c = a / b with the denominator floored to avoid a singularity (thyroid FTI = TT4/T4U).
            derived, a, b = v
            denominator = b.clamp(min=1e-3) if hasattr(b, "clamp") else np.maximum(b, 1e-3)
            return abs(derived - a / denominator)
        if rule.kind == "bmi":
            bmi, weight, height = v
            metres = height / 100
            metres = metres.clamp(min=.3) if hasattr(metres, "clamp") else np.maximum(metres, .3)
            return abs(bmi - weight / metres ** 2)
        if rule.kind == "scaled_product":
            derived, a, b = v
            return abs(derived - rule.bound * a * b)
        if rule.kind == "scaled_ratio":
            derived, a, b = v
            denominator = b.clamp(min=1e-3) if hasattr(b, "clamp") else np.maximum(b, 1e-3)
            return abs(derived - rule.bound * a / denominator)
        if rule.kind == "complement":
            derived, *rest = v
            return abs(derived - (rule.bound - sum(rest)))
        if rule.kind == "linear":
            derived, *rest = v
            return abs(derived - (rule.bound + sum(w * x for w, x in zip(rule.weights, rest))))
        if rule.kind == "structure":
            # Hyperedge membership only: contributes incidence to the model and no energy or violations.
            return 0 * v[0]
        if rule.kind == "parity":
            # Expected violation under factorized categorical probabilities.
            a, b, c = v
            return (1 - (1 - 2*a) * (1 - 2*b) * (1 - 2*c)) / 2
        raise ValueError(f"Unknown rule kind {rule.kind}")

    def evaluate(self, frame):
        results = {}
        any_eligible = np.zeros(len(frame), dtype=bool)
        any_violation = np.zeros(len(frame), dtype=bool)
        for rule in self.rules:
            valid = frame[list(rule.columns)].notna().all(axis=1).to_numpy()
            vals = {c: pd.to_numeric(frame[c], errors="coerce").to_numpy() for c in rule.columns}
            raw = np.asarray(self.residual(rule, vals), dtype=float)
            valid &= np.isfinite(raw)
            severity = np.maximum(raw - rule.tolerance, 0) / rule.scale
            n = int(valid.sum())
            violated = valid & (severity > 1e-6)
            any_eligible |= valid
            any_violation |= violated
            results[rule.name] = {"eligible": n, "coverage": n / max(len(frame), 1),
                "violation_rate": float(violated.sum()/n) if n else None,
                "mean_severity": float(severity[valid].mean()) if n else None,
                "status": rule.status, "tolerance": rule.tolerance, "scale": rule.scale,
                "confidence": rule.confidence}
        return {"rules": results, "any_rule_violation_rate": float(any_violation.sum()/any_eligible.sum()) if any_eligible.any() else None,
                "any_rule_coverage": float(any_eligible.mean()) if len(frame) else 0}

    def energy(self, numeric, logits, preprocessor, observed=None, detach_masks=True):
        """Per-row energy. Do not backpropagate into eligibility/missingness masks.

        At training use real observation masks. At sampling use detached predicted
        observation probabilities, avoiding a direct incentive to hide violations.
        Final observed coverage still needs auditing for indirect evasion.
        """
        values = {}
        eligibility = {}
        # The preprocessor owns the differentiable decode (affine or fit-only quantile).
        physical = preprocessor.physical_torch(numeric)
        for i, col in enumerate(preprocessor.schema.numeric):
            values[col] = physical[i]
            mask_index = len(preprocessor.cat_names) + i
            p_observed = logits[mask_index].softmax(-1)[:, 1]
            eligibility[col] = observed[:, i] if observed is not None else p_observed.detach() if detach_masks else p_observed
        for i, col in enumerate(preprocessor.cat_names):
            levels = preprocessor.levels[i]
            probs = logits[i].softmax(-1)
            if "1" in levels:
                values[col] = probs[:, levels.index("1")]
            eligibility[col] = 1 - probs[:, levels.index(preprocessor.missing)].detach() - probs[:, levels.index(preprocessor.unknown)].detach()
        energy = numeric.new_zeros(numeric.shape[0])
        weights = 0.0
        for rule in self.rules:
            residual = self.residual(rule, values)
            severity = torch.relu(residual - rule.tolerance) / rule.scale
            mask = torch.ones_like(energy)
            for col in rule.columns:
                mask = mask * eligibility[col]
            # SmoothL1-like growth prevents one corrupt lab from dominating gradients.
            penalty = torch.where(severity < 1, .5 * severity.square(), severity - .5)
            energy = energy + rule.confidence * mask * penalty
            weights += rule.confidence
        return energy / max(weights, 1.0)


def build_constraints(schema, train):
    source = f"https://archive.ics.uci.edu/dataset/{schema.uci_id}" if schema.uci_id else "controlled toy generator"
    rules = []
    for col in schema.numeric:
        scale = float(train[col].std())
        scale = scale if np.isfinite(scale) and scale > 1e-6 else 1
        rules.append(Rule(f"{col}_nonnegative", "lower", (col,), scale=scale, source=source))
    if schema.name == "heart_failure":
        rules.append(Rule("ejection_fraction_percentage", "upper", ("ejection_fraction",), bound=100, scale=100, source=source))
    if schema.name in ("ilpd", "toy"):
        rules.append(Rule("albumin_le_total", "le", ("albumin", "total_protein"),
                          status="soft_biochemical" if schema.name == "ilpd" else "controlled", source=PROTEIN_SOURCE))
        # Tolerance estimated solely from fit data is a descriptive residual envelope,
        # not a clinical acceptance threshold or calibrated confidence probability.
        raw = train.ag_ratio * (train.total_protein - train.albumin) - train.albumin
        raw = raw.abs().dropna()
        tolerance = float(raw.quantile(.95)) if len(raw) and schema.name == "ilpd" else .02
        rules.append(Rule("protein_identity", "protein", ("total_protein", "albumin", "ag_ratio"),
            confidence=.5 if schema.name == "ilpd" else 1, tolerance=tolerance,
            status="exploratory_train_calibrated" if schema.name == "ilpd" else "controlled", source=PROTEIN_SOURCE))
    if schema.name == "ilpd":
        rules.append(Rule("direct_le_total_bilirubin", "le", ("direct_bilirubin", "total_bilirubin"),
            confidence=.75, tolerance=.1, scale=1, status="soft_biochemical", source=BILIRUBIN_SOURCE))
    if schema.name == "toy":
        rules.append(Rule("parity", "parity", ("symptom_a", "symptom_b", "symptom_c"), status="controlled", source="toy XOR mechanism"))
    if schema.name == "nhanes":
        # NHANES documentation: globulin is calculated as total protein minus albumin; BMI is weight (kg)
        # divided by height (m) squared, rounded to 0.1. Tolerances are half the recording resolution.
        rules.append(Rule("globulin_identity", "difference", ("globulin", "total_protein", "albumin"), tolerance=.05 + 1e-6,
                          status="definitional", source="https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/BIOPRO_J.htm"))
        rules.append(Rule("bmi_identity", "bmi", ("bmi", "weight", "height"), tolerance=.05 + 1e-6, status="definitional",
                          source="https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/BMX_J.htm"))
        rules.append(Rule("albumin_le_total", "le", ("albumin", "total_protein"), status="soft_biochemical", source=PROTEIN_SOURCE))
    def envelope(rule):
        raw = np.asarray(ConstraintSet([rule]).residual(rule, {c: train[c].to_numpy(float) for c in rule.columns}), float)
        raw = raw[np.isfinite(raw)]
        return replace(rule, tolerance=float(np.quantile(raw, .95)) if len(raw) else .1)
    if schema.name.startswith("nhanes_chem"):
        # NHANES-reported relations (BIOPRO, ALB_CR and BMX documentation); envelopes as for the CBC panel.
        for rule in (Rule("globulin_identity", "difference", ("globulin", "total_protein", "albumin")),
                     Rule("bmi_identity", "bmi", ("bmi", "weight", "height")),
                     Rule("acr_index", "scaled_ratio", ("acr", "urine_albumin", "urine_creatinine"), bound=100.),
                     Rule("osmolality_formula", "linear", ("osmolality", "sodium", "glucose", "bun"), bound=9.,
                          weights=(1.86, 1 / 18, 1 / 2.8))):
            rules.append(envelope(replace(rule, confidence=.5, status="exploratory_train_calibrated",
                                          source="https://wwwn.cdc.gov/nchs/nhanes/ (BIOPRO, ALB_CR, BMX documentation)")))
    if schema.name.startswith("nhanes_cbc"):
        # Analyser-computed indices and the differential sum hold up to reporting rounding; tolerances are
        # fit 95th percentiles (descriptive envelopes), so about 5% of real records violate by construction.
        for rule in (Rule("hct_index", "scaled_product", ("hct", "rbc", "mcv"), bound=.1),
                     Rule("mch_index", "scaled_ratio", ("mch", "hgb", "rbc"), bound=10.),
                     Rule("mchc_index", "scaled_ratio", ("mchc", "hgb", "hct"), bound=100.),
                     Rule("differential_sum", "complement", ("baso_pct", "lymph_pct", "mono_pct", "neut_pct", "eos_pct"), bound=100.)):
            rules.append(envelope(replace(rule, confidence=.5, status="exploratory_train_calibrated",
                                          source="https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/2017/DataFiles/CBC_J.htm")))
    if schema.name == "thyroid":
        # FTI is reported as a function of TT4 and T4U; rounding and entry errors make it approximate,
        # so the tolerance is the fit-partition 95th percentile, a descriptive envelope like ILPD's.
        raw = (train.fti - train.tt4 / train.t4u.clip(lower=1e-3)).abs().dropna()
        rules.append(Rule("fti_ratio", "ratio", ("fti", "tt4", "t4u"), confidence=.5, tolerance=float(raw.quantile(.95)) if len(raw) else 1.,
                          status="exploratory_train_calibrated", source="UCI thyroid0387 documentation (Garvan Institute)"))
    return ConstraintSet(rules)


def with_unit_confidence(constraints):
    return ConstraintSet([replace(r, confidence=1.) for r in constraints.rules])


def repair_simple(frame, constraints):
    """Transparent postprocessing comparator; return corrected copy and change rate.

    Only supports the simple constraints used here; never used silently by diffusion.
    Missing values are preserved. This is not an implementation of HFGF/C-DGM.
    """
    fixed = frame.copy()
    for rule in constraints.rules:
        cols = rule.columns
        if rule.kind == "lower":
            fixed[cols[0]] = fixed[cols[0]].clip(lower=rule.bound)
        elif rule.kind == "upper":
            fixed[cols[0]] = fixed[cols[0]].clip(upper=rule.bound)
        elif rule.kind == "le":
            eligible = fixed[list(cols)].notna().all(axis=1)
            fixed.loc[eligible, cols[0]] = np.minimum(fixed.loc[eligible, cols[0]], fixed.loc[eligible, cols[1]])
        elif rule.kind == "protein":
            total, albumin, ratio = cols
            eligible = fixed[list(cols)].notna().all(axis=1)
            globulin = (fixed[total] - fixed[albumin]).clip(lower=.1)
            fixed.loc[eligible, total] = fixed.loc[eligible, albumin] + globulin[eligible]
            fixed.loc[eligible, ratio] = fixed.loc[eligible, albumin] / globulin[eligible]
        elif rule.kind in ("difference", "ratio", "bmi"):
            derived, a, b = cols
            eligible = fixed[list(cols)].notna().all(axis=1)
            if rule.kind == "difference":
                value = fixed[a] - fixed[b]
            elif rule.kind == "ratio":
                value = fixed[a] / fixed[b].clip(lower=1e-3)
            else:
                value = fixed[a] / (fixed[b].clip(lower=30) / 100) ** 2
            fixed.loc[eligible, derived] = value[eligible]
        elif rule.kind == "parity":
            a, b, c = cols
            eligible = fixed[list(cols)].notna().all(axis=1)
            fixed.loc[eligible, c] = (fixed.loc[eligible, a].astype(int) ^ fixed.loc[eligible, b].astype(int)).astype(str)
    changed = ~(fixed.eq(frame) | (fixed.isna() & frame.isna())).all(axis=1)
    return fixed, float(changed.mean())
